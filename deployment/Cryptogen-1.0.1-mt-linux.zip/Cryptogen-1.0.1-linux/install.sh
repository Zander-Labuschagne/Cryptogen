sudo mkdir /opt/Cryptogen
sudo mkdir /opt/Cryptogen/res
sudo mksir /opt/Cryptogen/bin
sudo cp -p bin/CryptogenV1.0.jar bin/CryptogenV1.0.sh /opt/Cryptogen/bin/
sudo cp -p res/cryptogen.png /opt/Cryptogen/res/
sudo cp -p bin/Cryptogen.desktop /usr/share/applications/
